//Declaring Convolution Function
void convolution(float x1[], int lenx1, float h1[], int lenh1, float y1[], int leny1);
//Declaring Correlation Function
void correlation(float x2[], int lenx2,float y2[], int leny2, float R_xy[], int lenR_xy);
//Declaring Downsampling Function
void downsampling(float x3[], int lenx3,float y3[], int leny3,float y4[], int leny4);
//Declaring Upsampling Function
void upsampling(float x4[], int lenx4,float y5[], int leny5,float y6[], int leny6);
